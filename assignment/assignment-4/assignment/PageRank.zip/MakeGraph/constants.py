BASE_PATH = '/home/ppipee/Desktop/CPE/web-ir/assignment/html/'

START_URL = 'https://ku.ac.th/faculty-of-engineering'

FILE_BLACKLISTS = ['.css', '.js', '.json', '.webp', '.xml', '.c', '.cc',
                   '.png', '.jpg', '.svg', '.jpeg', '.tiff',  '.bmp',
                   '.mp3', '.mp4', '.gif', '.ts', '.avi', '.flv', '.mkv', '.ovf', '.vmdk',
                   '.pdf', '.xlsx', '.pptx', '.docx', '.txt', '.ppt',
                   '.zip', '.rar', '.tar.gz', '.deb', '.exe'
                   ]

WORD_BLACKLISTS = ['download']
